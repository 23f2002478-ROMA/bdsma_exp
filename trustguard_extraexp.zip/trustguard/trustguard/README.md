# TrustGuard

Opportunity trust and scam detection for student internship and freelance listings.
Social media analytics mini project.

## What problem this solves

Students get job and internship posts forwarded through WhatsApp groups, Telegram
channels and Instagram pages. A good share of them are fake: the pattern is a high
salary, no interview, and a small "registration fee" that disappears. The post that
reaches a student has usually been forwarded many times and stripped of context, so
the student cannot tell a real listing from a recycled scam template.

TrustGuard takes one listing and returns a trust score out of 100 with every
deduction shown, so the student can check the reasoning rather than trust a verdict.

## How to run

```
pip install -r requirements.txt
python src/gen_data.py
python -m src.model
streamlit run app.py
```

The first command builds the corpus, the second trains the classifier, the third
starts the app on localhost:8501.

## The approach, in order

### 1. The score is a rule table, not a model output

The score starts at 100. Every rule that fires subtracts a fixed published weight,
and the app prints the arithmetic. This is a deliberate design choice. If a student
is told "this is 23 percent trustworthy" by a neural network, they cannot argue with
it. If they are told "minus 22 because the post asks for a registration fee, minus 24
because this exact paragraph appears under three other company names", they can check
each claim themselves. A scam detector that students do not trust does not get used.

Each category is capped (`CAT_CAP` in `src/score.py`) so that one noisy category
cannot sink a listing on its own.

### 2. The seven checks

| Check | What it looks for | File |
|---|---|---|
| Employer information | no company name, no website, free mail domain, email domain not matching the site, description too thin to judge | `rules.py` |
| Upfront payment | registration fee, security deposit, training kit, processing charge, UPI id attached to a job post | `rules.py` |
| Unrealistic claims | no experience or interview needed, guaranteed income, daily payout, artificial scarcity, pay far above the band for that role | `rules.py` |
| Copied description | TF-IDF cosine similarity against the whole corpus; the strong signal is the same paragraph under a different company name | `similarity.py` |
| Deadline and contact | deadline before the posting date, deadline within two days, malformed phone, chat-only contact, shortened links | `rules.py` |
| Account signals | account age, follower count, shares out of proportion to followers, closed-platform posting, one account posting for several companies | `social.py` |
| Scam network | shared payout rail or mailbox across different company names, plus coordinated posting bursts | `network.py` |

### 3. Scam network graph

This is the part that does the real work.

A scam operator can change the company name in a minute. What they do not change is
the thing that collects the money: the same UPI id, the same phone number, the same
throwaway mailbox keeps turning up. So listings become nodes in a graph, and an edge
means "these two share something an honest pair of listings would not share":

- the same UPI id or phone number (hard evidence, always linked)
- the same mailbox or a near identical description, **but only when the two company
  names differ** (a shared `careers@` address across posts from one real employer is
  normal, and linking on it would merge every genuine company into one blob)

Connected components of that graph are operators. One flagged post then exposes the
other twelve posted under different names.

Two details that mattered in practice. Handle prefixes were dropped as a linking key:
too many unrelated accounts share a common word, and the graph chained into a single
component. And the text-similarity threshold sits at 0.92 with a different-company
requirement, for the same reason.

### 4. Coordinated burst detection

Real employers post a role and wait. A campaign dumps its posts across many throwaway
accounts in a short window. For each cluster the posts are bucketed by hour and the
busiest bucket is compared against the cluster's own mean, giving a z-score. A cluster
is a burst when it has at least five posts inside a 24 hour span and either a z-score
above 2 or more than 1.5 posts per hour. In the shipped corpus five of six operators
show up as bursts spanning two to three hours.

### 5. The neural model is a second opinion, not the score

A small PyTorch MLP over TF-IDF features plus numeric social features
(`src/model.py`). It is reported next to the rule score and never folded into it.

The point of having both is the disagreement. The rules only catch patterns that were
written down; the model learns scam wording as a whole. When the two disagree, the
listing goes to human review instead of receiving a confident verdict.

Held out 25 percent: accuracy 0.993, precision 1.0, recall 0.977, F1 0.989, AUC 1.0.

Recall below 1.0 is not noise. Those are the **stealth** listings described below:
scam posts written in clean professional language with no trigger words at all. Text
alone misses them, and the network graph is what catches them. That is the argument
for building both.

### 6. Human review queue

Listings land in the queue when the score falls in the uncertain band (40 to 70), or
when the rules and the model disagree. A reviewer marks Scam, Legit or Need more info
with a note, backed by sqlite so decisions survive a restart (`src/queue_db.py`).
Decisions export as a retraining csv, which closes the loop: the model gets labelled
data for exactly the cases it was unsure about.

### 7. The non-technical half

A detector that only engineers can read does not help a student being scammed.

- a plain verdict (SAFER, CAUTION, HIGH RISK) with a one line reason
- every deduction written in student language with the matched evidence quoted
- concrete next steps: never pay a fee, do not share Aadhaar or PAN or bank details
  before a written offer on letterhead, verify on LinkedIn and MCA, report on
  cybercrime.gov.in
- a **verification message generator**: the exact five questions to send an employer
  (official domain email, CIN or GST, hiring manager's LinkedIn, written confirmation
  of no fees, offer letter before documents). A real employer answers all five.
  Pressure or a sudden change of contact channel after that message is itself the
  answer.
- only listing text is stored, no personal data

## The dataset

`src/gen_data.py` generates 567 labelled listings. Public job-posting datasets have no
social metadata and scraping live boards is against their terms, so the corpus is
synthetic but structured to contain the cases that matter:

| kind | n | what it is |
|---|---|---|
| legit | 260 | real companies, normal wording |
| lowqual | 70 | genuine but too thin to judge: no company, no deadline, three lines |
| scam | ~160 | classic fee-upfront scams, independent operators |
| stealth | ~34 | **scams written in clean professional language, no trigger words**, detectable only through the network fingerprint and social signals |
| oddlegit | 45 | **genuine small startups that trip the surface rules**: gmail address, no website yet, urgent tone, tight deadline |

The last two rows exist on purpose. Without `stealth` the classifier scores a perfect
1.0 and proves nothing. Without `oddlegit` there is no false-positive pressure, and a
detector that brands every bootstrapped startup a scam is useless to a student.

Three things had to be fixed while building, which are worth recording:

1. The first version hit F1 1.0 because scam and legit descriptions came from
   disjoint template pools, so the model was memorising templates. Stealth listings
   now draw from the **same** sentence pool as genuine ones.
2. Company names leaked the label, because invented names appeared only in scams.
   Stealth scams now impersonate real brands, which is also what actually happens.
3. Legit listings were generated from three templates, so they were near copies of
   each other and the duplicate check fired on every genuine post. Genuine
   descriptions are now assembled sentence by sentence from independent pools
   (`compose()`), because the duplicate signal only means something if honest posts
   are genuinely diverse.

## Results on the shipped corpus

| kind | mean score | verdicts |
|---|---|---|
| legit | 96 | 260 of 260 SAFER, zero false alarms |
| scam | 0 | all HIGH RISK |
| stealth | 35 | all CAUTION or HIGH RISK, none passed as safe |
| lowqual | 34 | split CAUTION / HIGH RISK |
| oddlegit | 41 | mostly CAUTION, which is the intended landing spot |

## Limitations

- The corpus is synthetic. The rule weights are reasoned, not fitted to real outcomes,
  and would need recalibration against real reports before anyone relied on the number.
- Pay bands are hardcoded for the Indian student market (`ROLE_BAND` in `rules.py`).
- The classifier metrics are measured on the same synthetic distribution it trained on,
  so they state internal consistency, not real-world accuracy.
- Network detection needs a corpus. A single listing checked in isolation only gets the
  text, consistency and account checks.

## Layout

```
app.py              Streamlit app: check, networks, review queue, analytics
src/gen_data.py     corpus generator
src/rules.py        checks 1, 2, 3, 5 and the shared empty-value helper
src/similarity.py   check 4, TF-IDF duplicate detection
src/social.py       check 6, account signals
src/network.py      check 7, fingerprint graph and burst detection
src/score.py        score assembly, review routing, verification message
src/model.py        PyTorch classifier, training and evaluation
src/queue_db.py     sqlite review queue and label export
src/pipeline.py     loads the corpus once, single check() entry point
```
