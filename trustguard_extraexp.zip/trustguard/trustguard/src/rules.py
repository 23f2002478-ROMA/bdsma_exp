"""Rule engine. Every rule returns a flag with a fixed, visible weight.

A flag is a dict:
  code   short id used in analytics
  cat    which of the six checks it belongs to
  msg    student facing one liner
  wt     points subtracted from the trust score
  ev     the evidence (matched text / value) so the UI can show why
"""

import re
from datetime import datetime

FREE_MAIL = {"gmail.com", "yahoo.com", "outlook.com", "rediffmail.com",
             "hotmail.com", "protonmail.com", "yandex.com", "mail.com"}

PAY_PAT = [
    (r"registration\s*fee", "registration fee"),
    (r"security\s*deposit", "security deposit"),
    (r"processing\s*(charge|fee)", "processing charge"),
    (r"refundable", "refundable payment"),
    (r"training\s*(kit|fee|charge)", "training fee"),
    (r"\bid\s*card\b.{0,30}\b(rs|inr|pay|fee)", "payment for ID card"),
    # Must not fire on a stated stipend ("we can pay Rs 12000 a month"), so the
    # amount cannot be followed by a per-month qualifier.
    (r"(pay|send|transfer|deposit)\s*(rs\.?|inr)\s*\d{2,6}(?!\s*(/|per\s*month|a\s*month|monthly|pm\b))",
     "asked to send money"),
    (r"\b[\w.\-]{3,}@(okaxis|ybl|paytm|oksbi|upi|okhdfcbank|apl)\b", "UPI id in the post"),
    (r"\b(paytm|phonepe|google\s*pay|gpay)\b.{0,25}\b(send|pay|transfer)", "wallet transfer"),
    (r"one\s*time\s*(payment|registration|charge)", "one time payment"),
]

HYPE_PAT = [
    (r"no\s*(experience|interview|degree|skill)s?\s*(needed|required)?", "no experience or interview needed"),
    (r"guarantee\w*\s*(income|payout|job|salary|selection)", "guaranteed income or selection"),
    (r"daily\s*(payout|payment|income)", "daily payout claim"),
    (r"(only\s*)?\d{1,2}\s*(seats?|vacanc\w+)\s*(left|remaining)", "artificial scarcity"),
    (r"limited\s*(time|seats|period)", "urgency language"),
    (r"(hurry|immediate\s*joining|filling\s*fast|do not miss)", "pressure language"),
    (r"100\s*percent\s*genuine", "unverifiable self praise"),
    (r"work\s*only\s*\d\s*hours?", "implausible working hours"),
    (r"earn\s*(rs\.?|inr)?\s*\d{4,}\s*(per\s*)?(day|week|daily|weekly)", "high pay for short period"),
    (r"zero\s*investment", "investment framing of a job"),
]

CONTACT_PAT = [
    (r"\b(telegram|t\.me)\b", "Telegram-only contact"),
    (r"\bwhats?app\b", "WhatsApp-only contact"),
]

SHORT_URL = r"(bit\.ly|tinyurl|rb\.gy|cutt\.ly|is\.gd|t\.ly|shorturl)"

ROLE_BAND = {
    "data entry": 12000, "typing": 10000, "form filling": 10000,
    "copy paste": 10000, "captcha": 8000, "ad posting": 10000,
    "review job": 10000, "promotion": 15000,
    "intern": 60000, "developer": 90000, "analyst": 70000,
    "engineer": 90000, "design": 60000, "writer": 50000,
}


def sv(x):
    """Empty-safe string. A csv round trip turns blanks into NaN, which then
    reads back as the literal text 'nan' and makes empty fields look populated."""
    if x is None:
        return ""
    s = str(x).strip()
    return "" if s.lower() in ("nan", "none", "nat", "<na>") else s


def _t(d):
    return " ".join(sv(d.get(k)) for k in ["title", "company", "desc", "pay_text"]).lower()


def r_employer(d):
    """Check 1: missing employer information."""
    f = []
    co = sv(d.get("company"))
    web = sv(d.get("website"))
    em = sv(d.get("email")).lower()
    if not co:
        f.append(dict(code="NO_CO", cat="employer", wt=18,
                      msg="No company name given", ev="company field empty"))
    if not web:
        f.append(dict(code="NO_WEB", cat="employer", wt=10,
                      msg="No company website listed", ev="website field empty"))
    if em and "@" in em:
        dom = em.split("@")[-1]
        if dom in FREE_MAIL:
            f.append(dict(code="FREE_MAIL", cat="employer", wt=14,
                          msg="Contact uses a personal email, not a company domain", ev=em))
        elif co and web and dom not in web:
            f.append(dict(code="DOM_MISMATCH", cat="employer", wt=12,
                          msg="Email domain does not match the company website", ev=em + " vs " + web))
    elif not em:
        f.append(dict(code="NO_MAIL", cat="employer", wt=8,
                      msg="No email contact given", ev="email field empty"))
    if len(sv(d.get("desc"))) < 120:
        f.append(dict(code="THIN_DESC", cat="employer", wt=8,
                      msg="Description is too short to judge the role", ev=str(len(sv(d.get("desc")))) + " chars"))
    return f


def r_payment(d):
    """Check 2: upfront payment requests."""
    t, f, seen = _t(d), [], set()
    for p, lab in PAY_PAT:
        m = re.search(p, t)
        if m and lab not in seen:
            seen.add(lab)
            f.append(dict(code="PAY_" + lab[:6].upper().replace(" ", ""), cat="payment", wt=22,
                          msg="Asks you to pay before working: " + lab, ev=m.group(0)[:60]))
    if sv(d.get("upi")):
        f.append(dict(code="UPI_FIELD", cat="payment", wt=20,
                      msg="A UPI id is attached to a job post", ev=sv(d.get("upi"))))
    return f[:4]


def r_claims(d):
    """Check 3: unrealistic salary and work claims."""
    t, f = _t(d), []
    for p, lab in HYPE_PAT:
        m = re.search(p, t)
        if m:
            f.append(dict(code="HYPE_" + lab[:6].upper().replace(" ", ""), cat="claims", wt=9,
                          msg=lab.capitalize(), ev=m.group(0)[:60]))
    pay = d.get("pay_month") or 0
    try:
        pay = float(pay)
    except Exception:
        pay = 0
    if pay > 0:
        band = 60000
        for k, v in ROLE_BAND.items():
            if k in t:
                band = v
                break
        if pay > band * 2:
            f.append(dict(code="PAY_HIGH", cat="claims", wt=16,
                          msg="Pay is far above the normal range for this kind of role",
                          ev="Rs " + str(int(pay)) + "/month vs typical ceiling Rs " + str(band)))
    return f[:5]


def r_consistency(d, today=None):
    """Check 5: deadline and contact consistency."""
    t, f = _t(d), []
    today = today or datetime.now()
    dl = sv(d.get("deadline"))
    if not dl:
        f.append(dict(code="NO_DL", cat="consistency", wt=6,
                      msg="No application deadline given", ev="deadline empty"))
    else:
        try:
            dd = datetime.strptime(dl, "%Y-%m-%d")
            post = d.get("posted_at")
            post = datetime.fromisoformat(str(post)[:19]) if post else today
            if dd < post:
                f.append(dict(code="DL_PAST", cat="consistency", wt=14,
                              msg="Deadline is earlier than the posting date", ev=dl))
            elif (dd - post).days <= 2:
                f.append(dict(code="DL_TIGHT", cat="consistency", wt=8,
                              msg="Deadline is within 2 days of posting", ev=dl))
        except ValueError:
            f.append(dict(code="DL_BAD", cat="consistency", wt=6,
                          msg="Deadline is not a valid date", ev=dl))
    pn = re.sub(r"\D", "", sv(d.get("phone")))
    if pn and not (10 <= len(pn) <= 12):
        f.append(dict(code="PH_BAD", cat="consistency", wt=8,
                      msg="Phone number is not a valid Indian number", ev=sv(d.get("phone"))))
    only_chat = [lab for p, lab in CONTACT_PAT if re.search(p, t)]
    if only_chat and not sv(d.get("website")):
        f.append(dict(code="CHAT_ONLY", cat="consistency", wt=12,
                      msg="Contact is only through " + " and ".join(only_chat).replace("-only contact", ""),
                      ev=", ".join(only_chat)))
    m = re.search(SHORT_URL, t)
    if m:
        f.append(dict(code="SHORT_URL", cat="consistency", wt=10,
                      msg="Uses a shortened link that hides the real destination", ev=m.group(0)))
    return f


def run_text_rules(d, today=None):
    return r_employer(d) + r_payment(d) + r_claims(d) + r_consistency(d, today)
