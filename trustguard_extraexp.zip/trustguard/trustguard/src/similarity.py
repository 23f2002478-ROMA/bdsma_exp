"""Check 4: copied or duplicate descriptions.

Two listings that are near identical but carry different company names are the
single strongest signal in this dataset: a real employer does not post the same
paragraph under four company names. We index the corpus with TF-IDF character
and word n-grams, then look at the nearest neighbours of the listing under test.
"""

import re

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

DUP_HI = 0.85
DUP_MID = 0.65


def norm(s):
    s = str(s or "").lower()
    s = re.sub(r"\d+", " num ", s)
    s = re.sub(r"[^a-z ]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


class SimIndex:
    def __init__(self, df, col="desc"):
        self.df = df.reset_index(drop=True)
        txt = [norm(x) for x in self.df[col]]
        self.vec = TfidfVectorizer(ngram_range=(1, 2), min_df=1, sublinear_tf=True)
        self.M = self.vec.fit_transform(txt)

    def nn(self, text, k=6, skip_id=None):
        """Return top k neighbours as (id, company, score)."""
        q = self.vec.transform([norm(text)])
        s = cosine_similarity(q, self.M)[0]
        idx = np.argsort(-s)[: k + 1]
        out = []
        for i in idx:
            row = self.df.iloc[i]
            if skip_id is not None and row["id"] == skip_id:
                continue
            out.append((row["id"], row.get("company", ""), float(s[i]), row.get("handle", "")))
            if len(out) >= k:
                break
        return out

    def flags(self, d):
        """Duplicate flags for one listing dict."""
        f = []
        nb = self.nn(d.get("desc", ""), k=5, skip_id=d.get("id"))
        if not nb:
            return f
        hi = [x for x in nb if x[2] >= DUP_HI]
        mid = [x for x in nb if DUP_MID <= x[2] < DUP_HI]
        co = str(d.get("company", "") or "").strip().lower()
        if hi:
            diff = [x for x in hi if str(x[1] or "").strip().lower() != co]
            if diff:
                f.append(dict(code="DUP_XCO", cat="duplicate", wt=24,
                              msg="Same description is posted under " + str(len(diff)) + " other company name(s)",
                              ev=", ".join(str(x[0]) + " (" + (str(x[1]) or "no name") + ", " +
                                           str(round(x[2], 2)) + ")" for x in diff[:3])))
            else:
                f.append(dict(code="DUP_SAME", cat="duplicate", wt=8,
                              msg="Description is reposted " + str(len(hi)) + " time(s)",
                              ev=", ".join(str(x[0]) for x in hi[:3])))
        elif mid:
            f.append(dict(code="DUP_TMPL", cat="duplicate", wt=10,
                          msg="Description closely follows a template used by other posts",
                          ev=", ".join(str(x[0]) + " (" + str(round(x[2], 2)) + ")" for x in mid[:3])))
        return f
