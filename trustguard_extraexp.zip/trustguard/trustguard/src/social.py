"""Check 6: social media account signals.

These are the features that make this a social media analytics project rather
than plain text classification. A throwaway account posting a job gives itself
away through its age, its follower to share ratio, and how many distinct
platforms the same post shows up on.
"""

from .rules import sv


def eng_ratio(d):
    fo = float(d.get("followers") or 0)
    sh = float(d.get("shares") or 0)
    return sh / fo if fo > 0 else (sh if sh else 0.0)


def flags(d, df=None):
    f = []
    age = d.get("acct_age_days")
    age = float(age) if age not in (None, "") else None
    fo = float(d.get("followers") or 0)
    sh = float(d.get("shares") or 0)

    if age is not None:
        if age < 30:
            f.append(dict(code="ACCT_NEW", cat="social", wt=16,
                          msg="Posting account is less than a month old", ev=str(int(age)) + " days"))
        elif age < 120:
            f.append(dict(code="ACCT_YOUNG", cat="social", wt=8,
                          msg="Posting account is fairly new", ev=str(int(age)) + " days"))
    if fo and fo < 500:
        f.append(dict(code="LOW_FOLLOW", cat="social", wt=8,
                      msg="Account has very few followers for a recruiting page",
                      ev=str(int(fo)) + " followers"))
    r = eng_ratio(d)
    if fo > 0 and r > 0.25 and sh >= 20:
        f.append(dict(code="SHARE_SPIKE", cat="social", wt=12,
                      msg="Shares are abnormally high relative to followers, typical of forwarded scam posts",
                      ev=str(int(sh)) + " shares on " + str(int(fo)) + " followers"))
    if sv(d.get("platform")) in ("Telegram", "WhatsApp") and not sv(d.get("website")):
        f.append(dict(code="PLAT_RISK", cat="social", wt=10,
                      msg="Posted on a closed messaging platform with no verifiable company page",
                      ev=sv(d.get("platform"))))

    # One employer account posting many of its own roles is normal. The signal
    # is one account posting for several different company names.
    if df is not None and sv(d.get("handle")):
        same = df[df["handle"] == d.get("handle")]
        ncos = len({sv(x) for x in same.get("company", []) if sv(x)})
        if len(same) >= 5 and ncos >= 2:
            f.append(dict(code="ACCT_SPAM", cat="social", wt=12,
                          msg="This account posts for " + str(ncos) + " different companies ("
                              + str(len(same)) + " listings)",
                          ev=sv(d.get("handle"))))
    return f
