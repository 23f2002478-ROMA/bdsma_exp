"""Loads the corpus once and exposes a single check() entry point."""

import os

import pandas as pd

from .similarity import SimIndex
from .network import NetIndex
from . import score as sc

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CSV = os.path.join(HERE, "data", "listings.csv")


class Engine:
    def __init__(self, csv=CSV, with_ml=True):
        # keep_default_na=False so blank fields stay "" instead of becoming NaN,
        # which would read back as the literal string "nan" downstream.
        self.df = pd.read_csv(csv, keep_default_na=False, dtype={"phone": str})
        self.df["posted_at"] = pd.to_datetime(self.df["posted_at"])
        for c in ["acct_age_days", "followers", "shares", "pay_month", "label"]:
            self.df[c] = pd.to_numeric(self.df[c], errors="coerce").fillna(0)
        self.sim = SimIndex(self.df)
        self.net = NetIndex(self.df, self.sim)
        self.ml = None
        if with_ml:
            try:
                from .model import Scorer
                self.ml = Scorer()
            except Exception as e:
                print("model not loaded:", e)

    def check(self, d):
        res = sc.assess(d, self.sim, self.net, self.df)
        p = self.ml.prob(d) if self.ml else None
        res["ml_prob"] = p
        need, why = sc.needs_review(res, p)
        res["needs_review"] = need
        res["review_why"] = why
        res["neighbors"] = self.sim.nn(d.get("desc", ""), k=5, skip_id=d.get("id"))
        res["verify_msg"] = sc.verify_msg(d)
        return res

    def score_all(self):
        rows = []
        for _, r in self.df.iterrows():
            d = r.to_dict()
            res = sc.assess(d, self.sim, self.net, self.df)
            rows.append(dict(id=d["id"], score=res["score"], verdict=res["verdict"],
                             label=d["label"], comp=res["comp"] or "",
                             n_flags=len(res["flags"]),
                             codes=",".join(x["code"] for x in res["flags"])))
        return pd.DataFrame(rows)
