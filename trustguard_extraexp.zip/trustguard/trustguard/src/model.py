"""PyTorch second opinion: TF-IDF text features plus a few numeric social
features into a small MLP.

Why a second model at all, when the rules already work. The rules only catch
patterns we wrote down. The model learns the wording of scam posts as a whole,
so it keeps a vote on listings that avoid every keyword we listed. Where the two
disagree, the listing goes to the human queue instead of getting a silent
verdict. That disagreement rule is the real value of having both.
"""

import os
import pickle

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score, confusion_matrix)

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MDL = os.path.join(HERE, "models")
NUM = ["acct_age_days", "followers", "shares", "pay_month"]


def txt_of(r):
    return " ".join(str(r.get(c, "") or "") for c in ["title", "company", "desc", "pay_text", "platform"])


def num_of(r):
    v = []
    for c in NUM:
        x = r.get(c)
        try:
            x = float(x)
        except Exception:
            x = 0.0
        v.append(np.log1p(max(x, 0.0)))
    fo = float(r.get("followers") or 0)
    sh = float(r.get("shares") or 0)
    v.append(sh / fo if fo > 0 else 0.0)
    v.append(1.0 if str(r.get("website", "") or "").strip() else 0.0)
    v.append(1.0 if str(r.get("upi", "") or "").strip() else 0.0)
    return v


class Net(nn.Module):
    def __init__(self, d):
        super().__init__()
        self.f = nn.Sequential(
            nn.Linear(d, 128), nn.ReLU(), nn.Dropout(0.3),
            nn.Linear(128, 32), nn.ReLU(), nn.Dropout(0.2),
            nn.Linear(32, 1),
        )

    def forward(self, x):
        return self.f(x).squeeze(-1)


def featurize(df, vec=None, fit=False):
    txt = [txt_of(r) for _, r in df.iterrows()]
    if fit:
        vec = TfidfVectorizer(max_features=3000, ngram_range=(1, 2), sublinear_tf=True, min_df=2)
        X = vec.fit_transform(txt)
    else:
        X = vec.transform(txt)
    N = np.array([num_of(r) for _, r in df.iterrows()], dtype=np.float32)
    N = N / (np.abs(N).max(axis=0, keepdims=True) + 1e-6)
    return np.hstack([X.toarray().astype(np.float32), N]), vec


def train(csv=None, epochs=40, seed=0):
    torch.manual_seed(seed)
    np.random.seed(seed)
    csv = csv or os.path.join(HERE, "data", "listings.csv")
    df = pd.read_csv(csv)
    y = df["label"].values.astype(np.float32)
    tr, te = train_test_split(np.arange(len(df)), test_size=0.25, random_state=seed, stratify=y)

    Xtr, vec = featurize(df.iloc[tr], fit=True)
    Xte, _ = featurize(df.iloc[te], vec=vec)
    ytr, yte = y[tr], y[te]

    m = Net(Xtr.shape[1])
    opt = torch.optim.Adam(m.parameters(), lr=1e-3, weight_decay=1e-4)
    lossf = nn.BCEWithLogitsLoss()
    Xt = torch.tensor(Xtr)
    yt = torch.tensor(ytr)

    for ep in range(epochs):
        m.train()
        perm = torch.randperm(len(Xt))
        tot = 0.0
        for i in range(0, len(Xt), 32):
            b = perm[i:i + 32]
            opt.zero_grad()
            l = lossf(m(Xt[b]), yt[b])
            l.backward()
            opt.step()
            tot += l.item()
        if (ep + 1) % 10 == 0:
            print("epoch", ep + 1, "loss", round(tot / max(1, len(Xt) // 32), 4))

    m.eval()
    with torch.no_grad():
        p = torch.sigmoid(m(torch.tensor(Xte))).numpy()
    pred = (p >= 0.5).astype(int)
    res = dict(
        acc=round(accuracy_score(yte, pred), 4),
        prec=round(precision_score(yte, pred, zero_division=0), 4),
        rec=round(recall_score(yte, pred, zero_division=0), 4),
        f1=round(f1_score(yte, pred, zero_division=0), 4),
        auc=round(roc_auc_score(yte, p), 4),
        cm=confusion_matrix(yte, pred).tolist(),
        n_test=int(len(yte)),
    )
    os.makedirs(MDL, exist_ok=True)
    torch.save({"sd": m.state_dict(), "d": Xtr.shape[1]}, os.path.join(MDL, "clf.pt"))
    with open(os.path.join(MDL, "vec.pkl"), "wb") as f:
        pickle.dump(vec, f)
    with open(os.path.join(MDL, "metrics.pkl"), "wb") as f:
        pickle.dump(res, f)
    print("test metrics", res)
    return res


class Scorer:
    def __init__(self):
        ck = torch.load(os.path.join(MDL, "clf.pt"), map_location="cpu", weights_only=False)
        self.m = Net(ck["d"])
        self.m.load_state_dict(ck["sd"])
        self.m.eval()
        with open(os.path.join(MDL, "vec.pkl"), "rb") as f:
            self.vec = pickle.load(f)
        with open(os.path.join(MDL, "metrics.pkl"), "rb") as f:
            self.metrics = pickle.load(f)

    def prob(self, d):
        X, _ = featurize(pd.DataFrame([d]), vec=self.vec)
        with torch.no_grad():
            return float(torch.sigmoid(self.m(torch.tensor(X)))[0])


if __name__ == "__main__":
    train()
