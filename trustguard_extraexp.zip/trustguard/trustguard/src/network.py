"""Added feature 1: scam network graph. Added feature 2: coordinated burst detection.

Idea. A single scam operator cannot change everything at once. The company name
is cheap to change, the payout rail is not: the same UPI id, the same phone, the
same throwaway mail domain and the same paragraph keep showing up. So we build a
graph where listings are nodes and an edge means "these two share something an
honest pair of listings would not share". Connected components of that graph are
operators.

Burst detection sits on top: for each component we bucket its posts by hour and
compute how far the busiest bucket sits above the component's own mean. Real
employers post one listing and wait; a campaign dumps 14 posts across 9 handles
in three hours.
"""

import re
from collections import defaultdict

import numpy as np
import networkx as nx

from .rules import sv
from sklearn.metrics.pairwise import cosine_similarity

LINK_SIM = 0.92
BURST_Z = 2.0
HARD = {"upi", "phone"}


def fp(d):
    """Fingerprint keys for one listing."""
    k = []
    u = sv(d.get("upi")).lower()
    if u:
        k.append(("upi", u))
    p = re.sub(r"\D", "", sv(d.get("phone")))
    if len(p) >= 10:
        k.append(("phone", p[-10:]))
    em = sv(d.get("email")).lower()
    if em and "@" in em:
        k.append(("mail", em))
    # Handle prefixes are deliberately NOT used for linking: too many unrelated
    # accounts share a common word and the graph chains into one blob.
    return k


def build(df, sim_idx, link_sim=LINK_SIM):
    """Return (graph, comp_map id->comp_id, comps dict)."""
    g = nx.Graph()
    for _, r in df.iterrows():
        g.add_node(r["id"])

    by_key = defaultdict(list)
    for _, r in df.iterrows():
        for k in fp(r):
            by_key[k].append(r["id"])

    co_of = dict(zip(df["id"], df["company"].fillna("").astype(str).str.strip().str.lower()))

    for k, ids in by_key.items():
        if len(ids) < 2 or len(ids) > 80:
            continue
        # A shared careers@ mailbox across posts of one real employer is normal.
        # The signal is a shared identity across DIFFERENT company names.
        if k[0] not in HARD and len({co_of.get(i, "") for i in ids}) <= 1:
            continue
        for i in range(len(ids) - 1):
            g.add_edge(ids[i], ids[i + 1], via=k[0], key=k[1])

    S = cosine_similarity(sim_idx.M)
    np.fill_diagonal(S, 0)
    ids = list(df["id"])
    r_i, c_i = np.where(S >= link_sim)
    for a, b in zip(r_i, c_i):
        if a < b and co_of.get(ids[a], "") != co_of.get(ids[b], ""):
            g.add_edge(ids[a], ids[b], via="text", key=round(float(S[a, b]), 2))

    comp_map, comps = {}, {}
    for n, cc in enumerate(nx.connected_components(g)):
        cid = "C" + str(n).zfill(3)
        for x in cc:
            comp_map[x] = cid
        comps[cid] = sorted(cc)
    return g, comp_map, comps


def burst(df, ids, z_thr=BURST_Z):
    """Burst stats for a set of listing ids."""
    sub = df[df["id"].isin(ids)]
    if len(sub) < 3:
        return dict(is_burst=False, n=len(sub), accts=sub["handle"].nunique(), z=0.0, span_h=0.0, peak=0)
    t = sub["posted_at"].astype("datetime64[ns]").astype("int64") // 10 ** 9
    span = (t.max() - t.min()) / 3600.0
    hb = (t // 3600)
    cnt = hb.value_counts()
    full = max(int(span) + 1, 1)
    mean = len(sub) / full
    sd = cnt.std() if len(cnt) > 1 else 0.0
    z = float((cnt.max() - mean) / sd) if sd > 0 else float(cnt.max())
    rate = len(sub) / max(span, 1.0)
    return dict(is_burst=bool(len(sub) >= 5 and span <= 24 and (z >= z_thr or rate >= 1.5)),
                n=int(len(sub)), accts=int(sub["handle"].nunique()),
                z=round(z, 2), span_h=round(float(span), 1), peak=int(cnt.max()))


class NetIndex:
    def __init__(self, df, sim_idx):
        self.df = df.reset_index(drop=True)
        self.g, self.comp_map, self.comps = build(self.df, sim_idx)
        self.bursts = {c: burst(self.df, ids) for c, ids in self.comps.items() if len(ids) > 1}
        self.cos = {}
        for c, ids in self.comps.items():
            sub = self.df[self.df["id"].isin(ids)]
            self.cos[c] = sorted({str(x).strip() for x in sub["company"].fillna("") if str(x).strip()})

    def comp_of(self, lid):
        return self.comp_map.get(lid)

    def match_new(self, d, sim_idx):
        """Attach an unseen listing to an existing component, by fingerprint or text."""
        keys = set(fp(d))
        co = sv(d.get("company")).lower()
        hits = []
        for _, r in self.df.iterrows():
            shared = keys & set(fp(r))
            if not shared:
                continue
            hard = [s for s in shared if s[0] in HARD]
            if not hard and sv(r.get("company")).lower() == co:
                continue
            s = (hard or list(shared))[0]
            hits.append((r["id"], s[0], s[1]))
        nb = [x for x in sim_idx.nn(d.get("desc", ""), k=5, skip_id=d.get("id")) if x[2] >= LINK_SIM]
        for x in nb:
            hits.append((x[0], "text", round(x[2], 2)))
        cids = {self.comp_map.get(h[0]) for h in hits if self.comp_map.get(h[0])}
        cid = None
        if cids:
            cid = max(cids, key=lambda c: len(self.comps.get(c, [])))
        return cid, hits

    def flags(self, d, sim_idx):
        f = []
        cid, hits = self.match_new(d, sim_idx)
        if not cid:
            return f, None, None
        ids = self.comps[cid]
        cos = self.cos.get(cid, [])
        if len(ids) >= 3 and len(cos) >= 2:
            vias = sorted({h[1] for h in hits})
            f.append(dict(code="NET_LINK", cat="network", wt=24,
                          msg="Shares contact details with " + str(len(ids) - 1) + " other listings posted under "
                              + str(len(cos)) + " different company names",
                          ev="shared " + ", ".join(vias) + "; names include " + ", ".join(cos[:3])))
        elif len(ids) >= 3:
            f.append(dict(code="NET_REPOST", cat="network", wt=8,
                          msg="Same source has " + str(len(ids) - 1) + " other near identical listings",
                          ev=", ".join(str(h[0]) for h in hits[:3])))
        b = self.bursts.get(cid)
        if b and b["is_burst"]:
            f.append(dict(code="BURST", cat="network", wt=14,
                          msg="Part of a coordinated burst: " + str(b["n"]) + " posts from " +
                              str(b["accts"]) + " accounts in " + str(b["span_h"]) + " hours",
                          ev="peak " + str(b["peak"]) + " posts/hour, z=" + str(b["z"])))
        return f, cid, b
