"""Human review queue, backed by sqlite so reviewer decisions survive restarts.

Uncertain listings land here instead of getting a confident wrong verdict.
Reviewer labels are exported as a retraining set, which closes the loop: the
model improves on exactly the cases it was unsure about.
"""

import os
import json
import sqlite3
from datetime import datetime

import pandas as pd

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB = os.path.join(HERE, "data", "review.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS queue (
  qid INTEGER PRIMARY KEY AUTOINCREMENT,
  lid TEXT, title TEXT, company TEXT, desc TEXT,
  score INTEGER, ml_prob REAL, reasons TEXT, flags TEXT,
  comp TEXT, status TEXT DEFAULT 'pending',
  decision TEXT, note TEXT, src TEXT,
  added_at TEXT, decided_at TEXT
);
"""


def con():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    c = sqlite3.connect(DB, check_same_thread=False)
    c.execute(SCHEMA)
    c.commit()
    return c


def add(d, res, ml_p, reasons, src="auto"):
    c = con()
    cur = c.execute("SELECT qid FROM queue WHERE lid=? AND status='pending'", (str(d.get("id", "")),))
    if str(d.get("id", "")) and cur.fetchone():
        c.close()
        return None
    c.execute(
        "INSERT INTO queue (lid,title,company,desc,score,ml_prob,reasons,flags,comp,src,added_at)"
        " VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (str(d.get("id", "")), str(d.get("title", "")), str(d.get("company", "")),
         str(d.get("desc", ""))[:2000], int(res["score"]),
         float(ml_p) if ml_p is not None else None,
         "; ".join(reasons), json.dumps(res["flags"][:12]),
         res.get("comp") or "", src, datetime.now().isoformat(timespec="seconds")),
    )
    c.commit()
    q = c.execute("SELECT last_insert_rowid()").fetchone()[0]
    c.close()
    return q


def pending():
    c = con()
    df = pd.read_sql_query("SELECT * FROM queue WHERE status='pending' ORDER BY qid DESC", c)
    c.close()
    return df


def all_rows():
    c = con()
    df = pd.read_sql_query("SELECT * FROM queue ORDER BY qid DESC", c)
    c.close()
    return df


def decide(qid, decision, note=""):
    c = con()
    c.execute("UPDATE queue SET status='done', decision=?, note=?, decided_at=? WHERE qid=?",
              (decision, note, datetime.now().isoformat(timespec="seconds"), int(qid)))
    c.commit()
    c.close()


def export_labels(path=None):
    """Reviewer decisions as a retraining csv."""
    path = path or os.path.join(HERE, "data", "review_labels.csv")
    df = all_rows()
    df = df[df.status == "done"]
    df = df[df.decision.isin(["Scam", "Legit"])].copy()
    if df.empty:
        return None, 0
    df["label"] = (df.decision == "Scam").astype(int)
    out = df[["lid", "title", "company", "desc", "label", "note", "decided_at"]]
    out.to_csv(path, index=False)
    return path, len(out)


def stats():
    df = all_rows()
    if df.empty:
        return dict(total=0, pending=0, done=0, scam=0, legit=0, unclear=0)
    return dict(
        total=len(df), pending=int((df.status == "pending").sum()),
        done=int((df.status == "done").sum()),
        scam=int((df.decision == "Scam").sum()),
        legit=int((df.decision == "Legit").sum()),
        unclear=int((df.decision == "Need more info").sum()),
    )
