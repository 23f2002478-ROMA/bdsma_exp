"""Transparent trust score.

Deliberately not a black box. The score starts at 100 and every rule that fires
subtracts its own fixed, published weight. The UI prints the arithmetic, so a
student can disagree with a specific deduction instead of being told "the model
says so". The neural model runs alongside and is reported as a second opinion,
never folded silently into the number.
"""

from . import rules, social
from .rules import sv

CAT_CAP = {"employer": 30, "payment": 45, "claims": 30,
           "duplicate": 28, "consistency": 25, "social": 30, "network": 34}

BANDS = [(70, "SAFER", "green"), (40, "CAUTION", "amber"), (0, "HIGH RISK", "red")]

VERDICT_TXT = {
    "SAFER": "Nothing major came up. Still verify the company yourself before sharing documents.",
    "CAUTION": "Some things do not add up. Do not share documents or pay anything until you have verified the employer.",
    "HIGH RISK": "This has the shape of a known scam pattern. Do not pay, do not share your ID or bank details.",
}


def band(s):
    for cut, name, col in BANDS:
        if s >= cut:
            return name, col
    return "HIGH RISK", "red"


def assess(d, sim_idx=None, net_idx=None, df=None, today=None):
    f = rules.run_text_rules(d, today)
    f += social.flags(d, df)
    if sim_idx is not None:
        f += sim_idx.flags(d)
    cid, b = None, None
    if net_idx is not None and sim_idx is not None:
        nf, cid, b = net_idx.flags(d, sim_idx)
        f += nf

    by_cat, ded = {}, 0.0
    for x in f:
        by_cat.setdefault(x["cat"], []).append(x)
    detail = {}
    for c, items in by_cat.items():
        raw = sum(i["wt"] for i in items)
        cap = CAT_CAP.get(c, 30)
        use = min(raw, cap)
        detail[c] = dict(raw=raw, capped=use, n=len(items))
        ded += use

    sc = max(0, min(100, round(100 - ded)))
    name, col = band(sc)
    return dict(score=sc, verdict=name, color=col, note=VERDICT_TXT[name],
                flags=sorted(f, key=lambda x: -x["wt"]), by_cat=detail,
                deduction=round(ded, 1), comp=cid, burst=b)


def needs_review(res, ml_p=None, lo=40, hi=70):
    """Route to the human queue on an uncertain score or a rules/model disagreement."""
    why = []
    if lo <= res["score"] < hi:
        why.append("score in the uncertain band")
    if ml_p is not None:
        rule_scam = res["score"] < lo
        ml_scam = ml_p >= 0.5
        if rule_scam != ml_scam:
            why.append("rule engine and model disagree")
    return (len(why) > 0), why


def verify_msg(d):
    """Draft the message a student should send to test the employer."""
    co = sv(d.get("company"))
    # With no company name the phrase "an official the employer domain" reads wrong,
    # so the sentence changes shape rather than slotting in a placeholder.
    q1 = ("1. Could you send this offer from an official " + co + " domain email address?\n"
          if co else "1. Could you tell me the registered company name and send this offer "
                     "from its official domain email address?\n")
    return (
        "Hello, thank you for the opportunity. Before I proceed I would like to confirm a few details:\n\n"
        + q1 +
        "2. Could you share the company CIN or GST number and the registered office address?\n"
        "3. Could you share the name and LinkedIn profile of the hiring manager I will report to?\n"
        "4. Could you confirm in writing that there is no registration, training, deposit or kit fee "
        "at any stage of this process?\n"
        "5. Could you share a written offer or internship letter on company letterhead before I submit "
        "any identity documents?\n\n"
        "Once I have these I will be glad to move ahead. Thank you.\n\n"
        "Note: a genuine employer answers all five without hesitation. Pressure, excuses or a sudden "
        "change of contact channel after this message is itself the answer."
    )