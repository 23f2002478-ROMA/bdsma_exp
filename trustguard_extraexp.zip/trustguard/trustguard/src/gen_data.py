"""Synthetic dataset of internship / freelance listings with social metadata.

Real scraping of job boards is blocked by TOS and is messy, so we generate a
labelled corpus that reproduces the structure we care about:
  - legit listings from real-looking companies
  - independent one-off scams
  - scam networks: one operator posting many listings under different company
    names but reusing a phone / UPI / email fingerprint and a text template
  - burst campaigns: a network dumping its posts in a short time window across
    many throwaway accounts
"""

import os
import random
import json
from datetime import datetime, timedelta

import pandas as pd

SEED = 7
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

PLAT = ["LinkedIn", "Instagram", "Telegram", "WhatsApp", "X", "CollegeGroup", "Internshala"]

REAL_CO = [
    ("Zoho Corporation", "zoho.com"), ("Freshworks", "freshworks.com"),
    ("Postman", "postman.com"), ("Razorpay", "razorpay.com"),
    ("Zerodha", "zerodha.com"), ("Swiggy", "swiggy.in"),
    ("Tata Elxsi", "tataelxsi.com"), ("Persistent Systems", "persistent.com"),
    ("Mindtree", "mindtree.com"), ("Infosys", "infosys.com"),
    ("Sarvam AI", "sarvam.ai"), ("Krutrim", "krutrim.com"),
    ("CleverTap", "clevertap.com"), ("Chargebee", "chargebee.com"),
    ("Darwinbox", "darwinbox.com"), ("BrowserStack", "browserstack.com"),
    ("Hasura", "hasura.io"), ("Dunzo Labs", "dunzo.com"),
    ("Innovaccer", "innovaccer.com"), ("Zetwerk", "zetwerk.com"),
]

FAKE_CO = [
    "Global Career Solutions", "Elite Work Hub", "Prime Job Point",
    "Smart Earning Services", "Future Career Group", "Digital Income Hub",
    "Royal Placement Services", "Star Career Point", "Quick Earn Solutions",
    "Nextgen Opportunity Centre", "Bright Future Consultancy", "Alpha Job Cell",
]

ROLE = [
    "Machine Learning Intern", "Backend Developer Intern", "Data Analyst Intern",
    "Frontend Intern", "Android Developer Intern", "Research Intern",
    "Content Writer (Freelance)", "QA Automation Intern", "DevOps Intern",
    "UI UX Design Intern", "Business Analyst Intern", "Cloud Engineer Intern",
]

SCAM_ROLE = [
    "Work From Home Data Entry", "Typing Job Part Time", "Online Form Filling Job",
    "Copy Paste Work From Home", "Social Media Promotion Job",
    "Captcha Entry Work", "Ad Posting Job", "Amazon Product Review Job",
]

S_INTRO = [
    "{co} is hiring a {role} for our {city} office.",
    "We have an opening for a {role} on the {team} team at {co}.",
    "{co} ({city}) is looking to add a {role} this quarter.",
    "Applications are open for the {role} role at {co}.",
    "The {team} group at {co} is recruiting a {role}.",
    "Join {co} in {city} as a {role}.",
    "{co} invites applications for a {role} based out of {city}.",
    "We are growing the {team} team at {co} and need a {role}.",
    "Role: {role}. Team: {team}. Location: {city}. Company: {co}.",
    "{co} has a vacancy for a {role}, reporting into the {team} org.",
]
S_TASK = [
    "The work centres on {task}.",
    "Day to day you will be {task}.",
    "You will own {task} alongside two senior engineers.",
    "Most of the role is {task}, with some code review.",
    "Expect to spend your time {task}.",
    "The first project is {task}.",
    "This role contributes directly to {task}.",
    "Your mandate is {task}, measured on delivery not hours.",
]
S_REQ = [
    "We expect working knowledge of {req}.",
    "Required skills: {req}.",
    "You should be comfortable with {req}.",
    "Familiarity with {req} is necessary; everything else we will teach.",
    "Must have: {req}. Nice to have: exposure to CI pipelines.",
    "Candidates should bring {req} and a willingness to read other people's code.",
    "Prerequisites are {req} and solid fundamentals.",
]
S_PAY = [
    "Stipend is {pay} per month for {dur} months.",
    "We pay {pay} monthly over a {dur} month term.",
    "Compensation: {pay} per month, {dur} month duration.",
    "The internship runs {dur} months at {pay} per month.",
    "{dur} months, {pay} monthly, reviewed at the midpoint.",
    "Duration {dur} months. Stipend {pay} monthly, paid on the first.",
]
S_PROC = [
    "Process is an online assessment followed by two technical rounds.",
    "Shortlisting is on resume, then a take home task and a discussion.",
    "We do one screening call and one deep technical round, nothing more.",
    "Interviews are a DSA round, a project discussion and a manager round.",
    "Apply through the careers portal; our team replies within a week.",
    "Selection: portfolio review, then a paid trial task, then an offer.",
    "Three stages: screen, technical, culture fit. Usually done in ten days.",
    "Send a resume and a link to anything you have built.",
]
S_CLOSE = [
    "We do not charge candidates any fee at any stage.",
    "Pre placement offers are available for strong performers.",
    "Hybrid working, three days in office.",
    "Laptop and accounts are provided on day one.",
    "Mentorship is part of the role, not an afterthought.",
    "Write to the address below with your resume.",
    "Students in their pre final and final year are eligible.",
    "We are happy to coordinate with your placement cell.",
]

LEGIT_BODY = [
    "We are hiring {role} for a {dur} month internship at our {city} office. "
    "You will work with the {team} team on {task}. Requirements: {req}. "
    "Stipend {pay} per month. Apply through our careers page with your resume. "
    "Shortlisted candidates will have a technical round followed by a team fit round.",
    "{co} is looking for a {role} to join the {team} team in {city}. "
    "The role involves {task}. We expect familiarity with {req}. "
    "Duration {dur} months, stipend {pay} per month, hybrid working. "
    "Send your resume and GitHub profile to the address below. No fee is charged at any stage.",
    "Opening for {role} at {co}, {city}. Selected interns will contribute to {task} "
    "alongside full time engineers. Skills needed: {req}. "
    "Stipend {pay} per month for {dur} months with a pre placement offer for strong performers. "
    "Interview process: online assessment, then two technical discussions.",
]

SCAM_BODY = [
    "URGENT HIRING {role}. Earn {pay} per week from home. No experience no interview needed. "
    "Only {slots} seats left. Registration fee Rs {fee} refundable after first payout. "
    "Pay to UPI {upi} and send screenshot on WhatsApp to confirm your seat. Limited time offer.",
    "{role} available for all students. Daily payout guaranteed. Work only {hrs} hours a day "
    "and earn {pay} monthly. 100 percent genuine company. Pay a small security deposit of "
    "Rs {fee} for ID card and training kit. Contact on Telegram immediately, seats filling fast.",
    "Immediate joining {role}. Salary {pay}. No degree required, no interview, direct selection. "
    "Send Rs {fee} as processing charge to {upi} to receive your offer letter within 10 minutes. "
    "Hurry only {slots} vacancy left. Do not miss this golden opportunity.",
    "Part time job for students. {role}. Earn {pay} weekly, payment daily in your account. "
    "Just pay one time registration of Rs {fee} and get your work ID. "
    "Message on WhatsApp number given below. Zero investment after registration. Guaranteed income.",
    "{role} vacancy open for freshers. Monthly {pay} guaranteed income, daily payout facility. "
    "Small refundable security deposit Rs {fee} applicable for company ID and material. "
    "Transfer to {upi} and share the receipt. Only {slots} seats remaining, hurry.",
    "Golden chance. {role} with earning upto {pay}. No interview, direct selection for all candidates. "
    "One time processing charge Rs {fee} only. Send on {upi}, offer letter in 10 minutes. "
    "100 percent genuine company, limited time offer.",
    "Students wanted for {role}. Work only {hrs} hours daily and earn {pay}. "
    "Training kit fee Rs {fee} refundable with first salary. Pay at {upi}. "
    "Immediate joining, {slots} vacancy left, contact on Telegram now.",
    "Home based {role} available. Guaranteed income {pay} per week, no experience required. "
    "Registration fee Rs {fee} to confirm your seat, refundable after first payout. "
    "WhatsApp us the payment screenshot. Do not miss this opportunity.",
]

LOW_QUAL_BODY = [
    "{role} required. Interested candidates contact. Salary negotiable. Immediate joining.",
    "Hiring {role}. Good opportunity. Send resume. Details shared after shortlisting.",
    "{role} needed urgently. Freshers can apply. Contact for more info.",
    "We are looking for a {role}. Experience preferred but not mandatory. Call to discuss.",
    "Vacancy: {role}. Package as per industry standards. Share CV on the number below.",
    "{role} opening available. Candidates from any stream may apply. Walk in anytime.",
    "Opportunity for {role}. Growth oriented role. Interested people may revert with profile.",
    "{role} wanted for client project. Duration flexible. Revert for details.",
    "Position open for {role}. Good communication required. Apply soon.",
    "Need {role} immediately. Training provided. Contact HR for the process.",
]

CITY = ["Bengaluru", "Pune", "Hyderabad", "Mumbai", "Chennai", "Noida", "Remote", "Jodhpur"]
TEAM = ["platform", "data", "perception", "growth", "infrastructure", "search", "payments"]
TASK = [
    "building model evaluation pipelines", "improving API latency",
    "designing dashboards for product metrics", "writing integration tests",
    "migrating services to containers", "training and benchmarking small vision models",
    "cleaning and labelling datasets", "building internal tooling",
]
REQ = [
    "Python and basic SQL", "PyTorch and NumPy", "React and TypeScript",
    "Java and Spring Boot", "Docker and Linux", "pandas and scikit learn",
    "C++ and data structures", "AWS basics and Git",
]

UPI_H = ["okaxis", "ybl", "paytm", "oksbi", "upi"]
FREE_MAIL = ["gmail.com", "yahoo.com", "outlook.com", "rediffmail.com", "hotmail.com"]


def ph(r):
    return "+91" + str(r.choice([6, 7, 8, 9])) + "".join(str(r.randint(0, 9)) for _ in range(9))


def upi(r, n):
    return n.lower().replace(" ", "")[:10] + str(r.randint(10, 99)) + "@" + r.choice(UPI_H)


def compose(r, **kw):
    """Assemble a description from independent sentence pools so that two honest
    listings are not near copies of each other. Without this the duplicate
    detector would flag every genuine post."""
    pools = [S_INTRO, S_TASK, S_REQ, S_PAY, S_PROC, S_CLOSE]
    sents = [r.choice(p).format(**kw) for p in pools]
    if r.random() < 0.5:
        sents.append(r.choice(S_CLOSE).format(**kw))
    mid = sents[1:-1]
    r.shuffle(mid)
    return " ".join([sents[0]] + mid + [sents[-1]])


def mk_legit(r, t0):
    co, dom = r.choice(REAL_CO)
    role = r.choice(ROLE)
    pay = "Rs " + str(r.choice([15000, 20000, 25000, 30000, 35000, 40000, 50000]))
    body = compose(r, role=role, co=co, city=r.choice(CITY), team=r.choice(TEAM),
                   task=r.choice(TASK), req=r.choice(REQ), dur=r.choice([2, 3, 6]), pay=pay)
    post = t0 - timedelta(hours=r.randint(0, 24 * 45))
    return {
        "title": role, "company": co, "desc": body,
        "pay_text": pay + " per month", "pay_month": int(pay.split()[1]),
        "email": "careers@" + dom, "phone": ph(r) if r.random() < 0.4 else "",
        "upi": "", "website": "https://www." + dom,
        "deadline": (post + timedelta(days=r.randint(14, 45))).strftime("%Y-%m-%d"),
        "posted_at": post, "platform": r.choice(["LinkedIn", "Internshala", "CollegeGroup", "X"]),
        "handle": "@" + co.split()[0].lower() + "_careers",
        "acct_age_days": r.randint(400, 3000), "followers": r.randint(5000, 900000),
        "shares": r.randint(0, 120), "label": 0, "kind": "legit",
    }


def mk_lowqual(r, t0):
    co = r.choice(FAKE_CO)
    role = r.choice(ROLE)
    body = r.choice(LOW_QUAL_BODY).format(role=role)
    post = t0 - timedelta(hours=r.randint(0, 24 * 45))
    return {
        "title": role, "company": co if r.random() < 0.5 else "",
        "desc": body, "pay_text": "negotiable", "pay_month": 0,
        "email": co.split()[0].lower() + str(r.randint(1, 99)) + "@" + r.choice(FREE_MAIL),
        "phone": ph(r), "upi": "", "website": "",
        "deadline": "", "posted_at": post, "platform": r.choice(PLAT),
        "handle": "@" + co.split()[0].lower() + str(r.randint(1, 999)),
        "acct_age_days": r.randint(20, 400), "followers": r.randint(50, 3000),
        "shares": r.randint(0, 40), "label": 0, "kind": "lowqual",
    }


def mk_scam(r, t0, op=None):
    """op is a dict describing a network operator, or None for a lone scam.

    An operator reuses one template across all its posts, which is what makes a
    network detectable by text; different operators use different templates so
    the graph does not merge them into one blob."""
    co = op["co"] if op else r.choice(FAKE_CO)
    role = r.choice(SCAM_ROLE)
    wk = r.choice([8000, 10000, 12000, 15000, 25000])
    fee = r.choice([250, 499, 750, 999, 1500, 2000])
    u = op["upi"] if op else upi(r, co)
    ti = op["tmpl"] if op else r.randrange(len(SCAM_BODY))
    body = SCAM_BODY[ti].format(
        role=role, pay="Rs " + str(wk), fee=fee, upi=u,
        slots=r.randint(2, 9), hrs=r.choice([1, 2, 3]),
    )
    if op is None:
        # An independent scammer writes their own variant. Only a network reuses
        # one paragraph verbatim, which is what the duplicate check looks for.
        parts = [x.strip() for x in body.split(".") if x.strip()]
        r.shuffle(parts)
        if len(parts) > 3:
            parts = parts[:-1]
        body = ". ".join(parts) + "."
    if op:
        post = op["t"] + timedelta(minutes=r.randint(0, op["win"]))
        em = op["co"].split()[0].lower() + str(r.randint(1, 99)) + "@" + op["dom"]
        pn = op["phone"]
        hd = "@" + op["slug"] + "_" + str(r.randint(100, 999))
    else:
        post = t0 - timedelta(hours=r.randint(0, 24 * 45))
        em = co.split()[0].lower() + str(r.randint(1, 99)) + "@" + r.choice(FREE_MAIL)
        pn = ph(r)
        hd = "@" + co.split()[0].lower() + str(r.randint(1, 999))
    return {
        "title": role, "company": co if r.random() < 0.6 else "",
        "desc": body, "pay_text": "Rs " + str(wk) + " per week",
        "pay_month": wk * 4,
        "email": em, "phone": pn, "upi": u, "website": "",
        "deadline": (post - timedelta(days=r.randint(1, 10))).strftime("%Y-%m-%d")
        if r.random() < 0.35 else (post + timedelta(days=r.randint(0, 2))).strftime("%Y-%m-%d"),
        "posted_at": post, "platform": r.choice(["Telegram", "WhatsApp", "Instagram", "X"]),
        "handle": hd, "acct_age_days": r.randint(1, 90),
        "followers": r.randint(10, 800), "shares": r.randint(20, 900), "label": 1,
        "kind": "scam",
    }


STEALTH_BODY = [
    "{co} is expanding its {team} team and invites applications for the {role} position in {city}. "
    "The selected candidate will support {task}. Preferred skills include {req}. "
    "Monthly stipend {pay}. Onboarding documents will be collected before the start date; "
    "please keep your Aadhaar, PAN and a cancelled cheque ready for verification.",
    "Applications are open for {role} at {co}. Work location {city}, duration {dur} months, "
    "stipend {pay}. Responsibilities cover {task}. Candidates should know {req}. "
    "Selection is based on profile screening. Shortlisted applicants will be contacted on the "
    "number provided and onboarding will be completed over a call the same day.",
]

ODD_LEGIT_BODY = [
    "Tiny team here, we need a {role} and we need them soon. The job is {task}. "
    "Stipend {pay} a month, which is honestly what we can manage right now. "
    "We have no website yet. Happy to hop on a call, show you the repo and introduce the founders. "
    "We will never ask you for money.",
    "Hiring a {role} at our {city} coworking desk. Work is {task}. We can offer {pay} monthly. "
    "Mail comes from a personal account because our domain is still being set up. "
    "Ask for our LinkedIn profiles, we will send them. No fees, ever.",
    "Early stage, four of us, looking for a {role}. {task} is the first thing you would pick up. "
    "{pay} per month to start, revisited after eight weeks. "
    "We can talk to your college placement cell if that helps you verify us.",
    "Looking for a {role} to join quickly. The work: {task}. Stipend {pay} monthly. "
    "We are pre revenue so the website is a placeholder page. "
    "Call us, visit the office in {city}, verify however you like. We charge candidates nothing.",
    "Small team, 4 people. We need a {role} starting next week, so applying early helps. "
    "Work is {task}. We can pay {pay} a month, which is what an early stage team can afford. "
    "No website yet, we are pre launch. Happy to do a call and show you the codebase. "
    "We never ask for any money from candidates.",
    "Bootstrapped startup hiring {role} urgently, immediate joining. {task}. Stipend {pay}. "
    "We are two founders out of a coworking space in {city}, so mail comes from a personal id. "
    "Ask us anything, we will share our LinkedIn and talk to your placement cell if needed.",
]


def mk_stealth(r, t0, op):
    """Scam with clean professional wording. No fee keywords in the text at all:
    only the network fingerprint and the social signals give it away."""
    co = r.choice(REAL_CO)[0]
    role = r.choice(ROLE)
    pay = "Rs " + str(r.choice([45000, 55000, 60000]))
    post = op["t"] + timedelta(minutes=r.randint(0, op["win"]))
    kw = dict(co=co, role=role, city=r.choice(CITY), team=r.choice(TEAM),
              task=r.choice(TASK), req=r.choice(REQ), dur=r.choice([2, 3, 6]), pay=pay)
    body = compose(r, **kw) if r.random() < 0.6 else r.choice(STEALTH_BODY).format(**kw)
    return {
        "title": role, "company": co, "desc": body,
        "pay_text": pay + " per month", "pay_month": int(pay.split()[1]),
        "email": co.split()[0].lower() + ".hr@" + op["dom"],
        "phone": op["phone"], "upi": "", "website": "",
        "deadline": (post + timedelta(days=r.randint(3, 10))).strftime("%Y-%m-%d"),
        "posted_at": post, "platform": r.choice(["LinkedIn", "X", "Instagram"]),
        "handle": "@" + op["slug"] + "_hr" + str(r.randint(10, 99)),
        "acct_age_days": r.randint(40, 500), "followers": r.randint(150, 2200),
        "shares": r.randint(5, 120), "label": 1, "kind": "stealth",
    }


def mk_odd_legit(r, t0):
    """Genuine small startup that trips several surface rules: free mail, no
    website, urgent tone, tight deadline. The score should land in amber and go
    to human review, not get branded a scam."""
    co = r.choice(["Peppermint Labs", "Tinkerwell", "Olive Systems", "Yellowbrick AI",
                   "Hodu Tech", "Saltmine Analytics"])
    role = r.choice(ROLE)
    pay = "Rs " + str(r.choice([8000, 10000, 12000, 15000]))
    post = t0 - timedelta(hours=r.randint(0, 24 * 40))
    body = r.choice(ODD_LEGIT_BODY).format(
        role=role, task=r.choice(TASK), pay=pay, city=r.choice(CITY),
    )
    return {
        "title": role, "company": co, "desc": body,
        "pay_text": pay + " per month", "pay_month": int(pay.split()[1]),
        "email": co.split()[0].lower() + ".hiring@" + r.choice(FREE_MAIL),
        "phone": ph(r), "upi": "", "website": "",
        "deadline": (post + timedelta(days=r.randint(2, 6))).strftime("%Y-%m-%d"),
        "posted_at": post, "platform": r.choice(["LinkedIn", "X", "CollegeGroup"]),
        "handle": "@" + co.split()[0].lower(),
        "acct_age_days": r.randint(60, 600), "followers": r.randint(120, 2000),
        "shares": r.randint(0, 25), "label": 0, "kind": "oddlegit",
    }


def build(n_legit=260, n_low=70, n_lone=80, n_net=6, n_odd=45):
    r = random.Random(SEED)
    t0 = datetime(2026, 10, 20, 12, 0)
    rows, nets = [], []

    for _ in range(n_legit):
        rows.append(mk_legit(r, t0))
    for _ in range(n_low):
        rows.append(mk_lowqual(r, t0))
    for _ in range(n_lone):
        rows.append(mk_scam(r, t0))
    for _ in range(n_odd):
        rows.append(mk_odd_legit(r, t0))

    for i in range(n_net):
        co = FAKE_CO[i % len(FAKE_CO)]
        slug = co.split()[0].lower()
        op = {
            "co": co, "slug": slug, "dom": r.choice(FREE_MAIL),
            "phone": ph(r), "upi": upi(r, co),
            "tmpl": i % len(SCAM_BODY),
            "t": t0 - timedelta(hours=r.randint(2, 24 * 30)),
            "win": r.choice([120, 180, 240]),
        }
        k = r.randint(8, 16)
        for _ in range(k):
            d = mk_scam(r, t0, op)
            d["net_id"] = "NET" + str(i + 1)
            rows.append(d)
        ks = r.randint(5, 9) if i < 5 else 0
        for _ in range(ks):
            d = mk_stealth(r, t0, op)
            d["net_id"] = "NET" + str(i + 1)
            rows.append(d)
        nets.append({"net_id": "NET" + str(i + 1), "co": co, "phone": op["phone"],
                     "upi": op["upi"], "posts": k + ks, "stealth": ks})

    r.shuffle(rows)
    df = pd.DataFrame(rows)
    df["net_id"] = df.get("net_id", pd.Series([None] * len(df))).fillna("")
    df.insert(0, "id", ["L" + str(i).zfill(4) for i in range(len(df))])
    df["posted_at"] = pd.to_datetime(df["posted_at"])
    return df, nets


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    df, nets = build()
    df.to_csv(os.path.join(OUT, "listings.csv"), index=False)
    with open(os.path.join(OUT, "networks.json"), "w") as f:
        json.dump(nets, f, indent=2)
    print("rows", len(df))
    print("scam", int(df.label.sum()), "legit", int((df.label == 0).sum()))
    print("networks", len(nets))
    print("saved to", OUT)
