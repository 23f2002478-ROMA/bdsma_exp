"""TrustGuard: opportunity trust and scam detection for student job listings.

Run with:  streamlit run app.py
"""

import os
import json

import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import networkx as nx

from src.pipeline import Engine
from src import queue_db as q
from src import score as sc

st.set_page_config(page_title="TrustGuard", page_icon="TG", layout="wide")

COL = {"green": "#1a7f37", "amber": "#b26a00", "red": "#b3261e"}
CAT_NAME = {
    "employer": "Employer information", "payment": "Upfront payment",
    "claims": "Unrealistic claims", "duplicate": "Copied description",
    "consistency": "Deadline and contact", "social": "Account signals",
    "network": "Scam network",
}


@st.cache_resource
def load():
    return Engine()


def badge(res):
    c = COL[res["color"]]
    st.markdown(
        "<div style='border-left:8px solid " + c + ";padding:14px 18px;background:#00000008;"
        "border-radius:6px'><span style='font-size:34px;font-weight:700;color:" + c + "'>"
        + str(res["score"]) + "/100</span><span style='font-size:19px;margin-left:14px;"
        "font-weight:600;color:" + c + "'>" + res["verdict"] + "</span><br>"
        "<span style='font-size:15px'>" + res["note"] + "</span></div>",
        unsafe_allow_html=True,
    )


def show_flags(res):
    if not res["flags"]:
        st.success("No red flags were raised by any of the seven checks.")
        return
    st.markdown("Why this score")
    st.caption("Every check below subtracted points. Nothing else affected the number.")
    for f in res["flags"]:
        with st.container(border=True):
            a, b = st.columns([6, 1])
            a.markdown("**" + CAT_NAME.get(f["cat"], f["cat"]) + "** - " + f["msg"])
            a.caption("Evidence: " + str(f["ev"]))
            b.markdown("<div style='text-align:right;font-size:19px;font-weight:700;color:"
                       + COL["red"] + "'>-" + str(f["wt"]) + "</div>", unsafe_allow_html=True)
    d = res["by_cat"]
    rows = [dict(Check=CAT_NAME.get(k, k), Flags=v["n"], Raw=v["raw"], Applied=v["capped"])
            for k, v in d.items()]
    with st.expander("Score arithmetic"):
        st.caption("Each check is capped so that one category alone cannot sink a listing.")
        st.dataframe(pd.DataFrame(rows), hide_index=True, width='stretch')
        st.write("100 - " + str(res["deduction"]) + " = **" + str(res["score"]) + "**")


def page_check(e):
    st.header("Check a listing")
    mode = st.radio("Input", ["Pick from the dataset", "Paste a listing"],
                    horizontal=True, label_visibility="collapsed")

    if mode == "Pick from the dataset":
        df = e.df
        kind = st.selectbox("Filter by type", ["any"] + sorted(df["kind"].unique().tolist()))
        sub = df if kind == "any" else df[df["kind"] == kind]
        lab = {r["id"]: r["id"] + " | " + (str(r["company"]) or "no name") + " | " + str(r["title"])
               for _, r in sub.iterrows()}
        lid = st.selectbox("Listing", list(lab.keys()), format_func=lambda x: lab[x])
        d = df[df["id"] == lid].iloc[0].to_dict()
        with st.expander("Listing text", expanded=True):
            st.write(d["desc"])
            st.caption("Platform " + str(d["platform"]) + " | account " + str(d["handle"])
                       + " | age " + str(int(d["acct_age_days"])) + "d | followers "
                       + str(int(d["followers"])) + " | shares " + str(int(d["shares"])))
    else:
        c1, c2 = st.columns(2)
        d = {}
        d["title"] = c1.text_input("Role title", "Data Entry Work From Home")
        d["company"] = c2.text_input("Company name", "")
        d["desc"] = st.text_area(
            "Listing text", height=150,
            value="URGENT HIRING. Earn Rs 15000 per week from home. No experience no interview. "
                  "Only 3 seats left. Registration fee Rs 499 refundable after first payout. "
                  "Pay to UPI quickearn12@ybl and send screenshot on WhatsApp to confirm.")
        c1, c2, c3 = st.columns(3)
        d["email"] = c1.text_input("Contact email", "quickjobs88@gmail.com")
        d["phone"] = c2.text_input("Phone", "+919876543210")
        d["upi"] = c3.text_input("UPI id", "quickearn12@ybl")
        c1, c2, c3 = st.columns(3)
        d["website"] = c1.text_input("Company website", "")
        d["deadline"] = c2.text_input("Deadline (YYYY-MM-DD)", "")
        d["pay_month"] = c3.number_input("Stated pay per month (Rs)", 0, 10 ** 7, 60000, step=1000)
        d["pay_text"] = str(d["pay_month"]) + " per month"
        c1, c2, c3, c4 = st.columns(4)
        d["platform"] = c1.selectbox("Platform", ["WhatsApp", "Telegram", "Instagram", "LinkedIn",
                                                  "X", "Internshala", "CollegeGroup"])
        d["handle"] = c2.text_input("Account handle", "@quickjobs88")
        d["acct_age_days"] = c3.number_input("Account age (days)", 0, 5000, 12)
        d["followers"] = c4.number_input("Followers", 0, 10 ** 7, 220)
        d["shares"] = st.number_input("Shares", 0, 10 ** 6, 140)
        d["posted_at"] = pd.Timestamp.now()
        d["id"] = ""

    if not st.button("Run the checks", type="primary", width='stretch'):
        return
    res = e.check(d)
    badge(res)

    c1, c2, c3 = st.columns(3)
    c1.metric("Trust score", str(res["score"]) + "/100")
    c2.metric("Model scam probability",
              "n/a" if res["ml_prob"] is None else str(round(res["ml_prob"] * 100, 1)) + "%")
    c3.metric("Flags raised", len(res["flags"]))
    if res["ml_prob"] is not None:
        st.caption("The rule score and the model are computed independently. "
                   "They are shown side by side on purpose: when they disagree, "
                   "the listing goes to a human instead of getting a confident verdict.")

    if res["needs_review"]:
        st.warning("Uncertain: " + "; ".join(res["review_why"]) + ". This belongs in human review.")
        if st.button("Send to review queue"):
            q.add(d, res, res["ml_prob"], res["review_why"], src="manual")
            st.success("Added to the review queue.")

    show_flags(res)

    # Only a cluster of 3 or more under 2 or more company names is a network. A
    # cluster of one is just this listing, so showing it as an alert is wrong.
    ids = e.net.comps.get(res["comp"], []) if res["comp"] else []
    cos = e.net.cos.get(res["comp"], []) if res["comp"] else []
    if len(ids) >= 3:
        st.markdown("Network")
        if len(cos) >= 2:
            st.error("This listing is linked to cluster " + res["comp"] + ": " + str(len(ids))
                     + " listings posted under " + str(len(cos)) + " different company names.")
        else:
            st.warning("This listing sits in cluster " + res["comp"] + " with " + str(len(ids) - 1)
                       + " other near identical listings from the same source.")
        b = res["burst"]
        if b and b["is_burst"]:
            st.error("Coordinated burst: " + str(b["n"]) + " posts from " + str(b["accts"])
                     + " accounts within " + str(b["span_h"]) + " hours (peak "
                     + str(b["peak"]) + " per hour).")
        if cos:
            st.caption("Company names used by this cluster: " + ", ".join(cos[:10]))
        st.dataframe(e.df[e.df["id"].isin(ids)][
            ["id", "company", "title", "platform", "handle", "phone", "upi", "posted_at"]
        ].head(25), hide_index=True, width='stretch')

    st.markdown("Similar listings already seen")
    nb = pd.DataFrame(res["neighbors"], columns=["id", "company", "similarity", "handle"])
    nb["similarity"] = nb["similarity"].round(3)
    st.dataframe(nb, hide_index=True, width='stretch')

    st.markdown("What to do next")
    if res["score"] < 70:
        st.markdown(
            "- Do not pay anything. No legitimate employer charges a registration, "
            "training, deposit or kit fee.\n"
            "- Do not share Aadhaar, PAN, bank details or a cancelled cheque before a "
            "written offer on company letterhead.\n"
            "- Verify the company on LinkedIn and on the MCA master data portal.\n"
            "- Report the post to your placement cell and on cybercrime.gov.in.")
    else:
        st.markdown(
            "- Nothing major surfaced, but still confirm the recruiter from an official "
            "company domain email.\n"
            "- Keep every communication in writing.")
    with st.expander("Verification message you can send the employer"):
        st.caption("A genuine employer answers all five. Pressure or a sudden change of "
                   "contact channel after this message is itself the answer.")
        # st.code does not wrap, so long lines run off the edge and are cut in a
        # screenshot or a printout. A text area wraps and is still selectable.
        st.text_area("Message", res["verify_msg"], height=320, label_visibility="collapsed")


def page_network(e):
    st.header("Scam networks")
    st.caption("A single operator cannot change everything at once. The company name is cheap "
               "to change, the payout rail is not. Listings are linked when they share a UPI id, "
               "a phone number, a mailbox or a near identical description under a different "
               "company name. Connected groups are operators.")
    rows = []
    for c, ids in e.net.comps.items():
        if len(ids) < 3:
            continue
        sub = e.df[e.df["id"].isin(ids)]
        b = e.net.bursts.get(c, {})
        rows.append(dict(cluster=c, listings=len(ids), companies=len(e.net.cos[c]),
                         accounts=sub["handle"].nunique(),
                         platforms=sub["platform"].nunique(),
                         burst="yes" if b.get("is_burst") else "no",
                         span_hours=b.get("span_h", 0), peak_per_hour=b.get("peak", 0)))
    if not rows:
        st.info("No multi listing clusters found.")
        return
    t = pd.DataFrame(rows).sort_values("listings", ascending=False)
    st.dataframe(t, hide_index=True, width='stretch')

    cid = st.selectbox("Inspect cluster", t["cluster"].tolist())
    ids = e.net.comps[cid]
    sub = e.df[e.df["id"].isin(ids)]
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Listings", len(ids))
    c2.metric("Company names", len(e.net.cos[cid]))
    c3.metric("Accounts", sub["handle"].nunique())
    b = e.net.bursts.get(cid, {})
    c4.metric("Posted within", str(b.get("span_h", 0)) + " h")
    st.caption("Names used: " + ", ".join(e.net.cos[cid][:12]))

    g = e.net.g.subgraph(ids)
    pos = nx.spring_layout(g, seed=3)
    ex, ey, lab = [], [], []
    for a, bb, dd in g.edges(data=True):
        ex += [pos[a][0], pos[bb][0], None]
        ey += [pos[a][1], pos[bb][1], None]
    nx_, ny, txt, colr = [], [], [], []
    for n in g.nodes():
        r = e.df[e.df["id"] == n].iloc[0]
        nx_.append(pos[n][0]); ny.append(pos[n][1])
        txt.append(str(n) + "<br>" + (str(r["company"]) or "no name") + "<br>" + str(r["handle"])
                   + "<br>" + str(r["platform"]))
        colr.append(COL["red"] if r["label"] == 1 else COL["green"])
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=ex, y=ey, mode="lines", line=dict(width=1, color="#999"),
                             hoverinfo="none", showlegend=False))
    fig.add_trace(go.Scatter(x=nx_, y=ny, mode="markers", marker=dict(size=13, color=colr),
                             text=txt, hoverinfo="text", showlegend=False))
    fig.update_layout(height=430, margin=dict(l=0, r=0, t=10, b=0),
                      xaxis=dict(visible=False), yaxis=dict(visible=False))
    st.plotly_chart(fig, width='stretch')
    st.caption("Each dot is a listing, each line a shared identifier or a near identical "
               "description. Red dots are labelled scams in the dataset.")

    st.markdown("Posting timeline")
    tl = sub.copy()
    tl["hour"] = tl["posted_at"].dt.floor("h")
    cnt = tl.groupby("hour").size().reset_index(name="posts")
    st.plotly_chart(px.bar(cnt, x="hour", y="posts",
                           labels={"hour": "", "posts": "posts per hour"}).update_layout(height=250),
                    width='stretch')
    st.dataframe(sub[["id", "company", "title", "platform", "handle", "phone", "upi",
                      "acct_age_days", "posted_at"]], hide_index=True, width='stretch')


def page_queue(e):
    st.header("Human review queue")
    st.caption("Listings the system is not confident about: a score in the uncertain band, "
               "or the rule engine and the model disagreeing. These get a person, not a verdict.")
    s = q.stats()
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Pending", s["pending"])
    c2.metric("Reviewed", s["done"])
    c3.metric("Marked scam", s["scam"])
    c4.metric("Marked legit", s["legit"])

    with st.expander("Populate the queue from the dataset"):
        n = st.slider("How many listings to scan", 20, len(e.df), 120, step=20)
        if st.button("Scan and enqueue uncertain ones"):
            add = 0
            bar = st.progress(0.0)
            for i, (_, r) in enumerate(e.df.head(n).iterrows()):
                d = r.to_dict()
                res = e.check(d)
                if res["needs_review"]:
                    if q.add(d, res, res["ml_prob"], res["review_why"]) is not None:
                        add += 1
                bar.progress((i + 1) / n)
            st.success("Queued " + str(add) + " uncertain listings out of " + str(n) + " scanned.")
            st.rerun()

    p = q.pending()
    if p.empty:
        st.info("Queue is empty.")
    for _, r in p.head(25).iterrows():
        with st.container(border=True):
            a, b = st.columns([5, 2])
            a.markdown("**" + (str(r["company"]) or "no company name") + "** - " + str(r["title"]))
            a.caption(str(r["desc"])[:260] + "...")
            a.caption("Reason queued: " + str(r["reasons"]))
            b.metric("Score", r["score"])
            if r["ml_prob"] is not None and not pd.isna(r["ml_prob"]):
                b.caption("model: " + str(round(float(r["ml_prob"]) * 100, 1)) + "% scam")
            if r["comp"]:
                b.caption("cluster " + str(r["comp"]))
            with st.expander("Flags"):
                for f in json.loads(r["flags"]):
                    st.write("-" + str(f["wt"]) + "  " + f["msg"])
            note = st.text_input("Reviewer note", key="n" + str(r["qid"]), label_visibility="collapsed",
                                 placeholder="Optional note")
            x, y, z = st.columns(3)
            if x.button("Scam", key="s" + str(r["qid"]), width='stretch'):
                q.decide(r["qid"], "Scam", note); st.rerun()
            if y.button("Legit", key="l" + str(r["qid"]), width='stretch'):
                q.decide(r["qid"], "Legit", note); st.rerun()
            if z.button("Need more info", key="u" + str(r["qid"]), width='stretch'):
                q.decide(r["qid"], "Need more info", note); st.rerun()

    st.markdown("Export reviewed labels")
    st.caption("Reviewer decisions become a retraining set, so the model improves on exactly "
               "the cases it was unsure about.")
    if st.button("Export"):
        path, n = q.export_labels()
        if path:
            st.success("Wrote " + str(n) + " labelled rows to " + path)
        else:
            st.info("Nothing reviewed yet.")


def page_analytics(e):
    st.header("Analytics")
    sa = e.score_all().merge(e.df[["id", "kind", "platform", "posted_at"]], on="id")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Listings", len(sa))
    c2.metric("High risk", int((sa.verdict == "HIGH RISK").sum()))
    c3.metric("Caution", int((sa.verdict == "CAUTION").sum()))
    c4.metric("Clusters (3+)", sum(1 for v in e.net.comps.values() if len(v) >= 3))

    c1, c2 = st.columns(2)
    c1.plotly_chart(px.histogram(sa, x="score", color="verdict", nbins=25,
                                 color_discrete_map={"SAFER": COL["green"], "CAUTION": COL["amber"],
                                                     "HIGH RISK": COL["red"]},
                                 title="Trust score distribution").update_layout(height=330),
                    width='stretch')
    ct = sa.groupby(["platform", "verdict"]).size().reset_index(name="n")
    c2.plotly_chart(px.bar(ct, x="platform", y="n", color="verdict",
                           color_discrete_map={"SAFER": COL["green"], "CAUTION": COL["amber"],
                                               "HIGH RISK": COL["red"]},
                           title="Verdict by platform").update_layout(height=330),
                    width='stretch')

    st.markdown("Most common red flags")
    codes = []
    for s in sa["codes"]:
        codes += [c for c in str(s).split(",") if c]
    cc = pd.Series(codes).value_counts().head(15).reset_index()
    cc.columns = ["flag", "times fired"]
    st.plotly_chart(px.bar(cc, x="times fired", y="flag", orientation="h").update_layout(height=420),
                    width='stretch')

    st.markdown("How the score separates the labelled classes")
    st.caption("legit and oddlegit are genuine; scam and stealth are not; lowqual is real but "
               "too thin to judge. stealth posts are written in clean professional language and "
               "are the hard case for text alone.")
    # Colour by what the class actually is, not by its name. Arbitrary colours
    # here drew legit in red and scam in green, which reads backwards.
    truth = {"legit": "genuine", "oddlegit": "genuine", "lowqual": "low quality",
             "scam": "scam", "stealth": "scam"}
    sa["ground truth"] = sa["kind"].map(truth)
    st.plotly_chart(px.box(sa, x="kind", y="score", color="ground truth", points=False,
                           category_orders={"kind": ["legit", "oddlegit", "lowqual",
                                                     "stealth", "scam"]},
                           color_discrete_map={"genuine": COL["green"],
                                               "low quality": COL["amber"],
                                               "scam": COL["red"]}).update_layout(height=360),
                    width='stretch')
    st.dataframe(sa.groupby("kind")["score"].agg(["count", "mean", "min", "max"]).round(1),
                 width='stretch')

    if e.ml is not None:
        st.markdown("Model evaluation (held out 25 percent)")
        m = e.ml.metrics
        c = st.columns(5)
        for i, k in enumerate(["acc", "prec", "rec", "f1", "auc"]):
            c[i].metric(k, m[k])
        cm = m["cm"]
        st.plotly_chart(px.imshow(cm, text_auto=True, x=["pred legit", "pred scam"],
                                  y=["true legit", "true scam"], color_continuous_scale="Blues")
                        .update_layout(height=320, coloraxis_showscale=False),
                        width='stretch')
        st.caption("Recall below 1.0 is the stealth listings: scam posts written without a single "
                   "trigger word. Text alone misses them, which is why the network graph exists.")


def main():
    st.sidebar.title("TrustGuard")
    st.sidebar.caption("Opportunity trust and scam detection for student internships "
                       "and freelance listings.")
    pg = st.sidebar.radio("Go to", ["Check a listing", "Scam networks",
                                    "Review queue", "Analytics"])
    e = load()
    st.sidebar.markdown("Corpus: " + str(len(e.df)) + " listings")
    st.sidebar.markdown("Clusters: " + str(sum(1 for v in e.net.comps.values() if len(v) >= 3)))
    st.sidebar.caption("Scores come from a published rule table, not a black box. "
                       "The neural model is a second opinion shown alongside.")
    if pg == "Check a listing":
        page_check(e)
    elif pg == "Scam networks":
        page_network(e)
    elif pg == "Review queue":
        page_queue(e)
    else:
        page_analytics(e)


if __name__ == "__main__":
    main()